变更内容：
1) 新增/替换 Logo 资源：assets/logo.svg（黑）、assets/logo-white.svg（白底反白）、assets/logo-color.svg（彩色渐变）、assets/favicon.svg（方形图标）。
2) 页头字标更新：index.html 中 brand.name 由 "PLQU" 改为 "佩乐趣"，aria-label/alt 统一为“佩乐趣”。
3) 未改动其它版式与文案。

如需在深色页头使用，请把 <img src="assets/logo.svg"> 改为 <img src="assets/logo-white.svg">。
